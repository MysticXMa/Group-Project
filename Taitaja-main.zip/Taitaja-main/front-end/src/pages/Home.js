import React from 'react';
import '../App.css';

function Home() {
  return (
    <h2 style={{ color: '#8FB83B' }}>Main page</h2>
  );
}

export default Home;
