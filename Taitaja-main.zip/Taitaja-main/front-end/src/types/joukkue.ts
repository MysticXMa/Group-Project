export type Joukkue = {
    ryhmä: number
    koulu: string
    joukkue: string
}  